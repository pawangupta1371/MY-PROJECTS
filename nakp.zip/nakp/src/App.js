import { BrowserRouter, Route, Routes } from "react-router-dom";
import Home from "./Home/Home";
import Dinning from "./Dinning/Dinning";
import Gallery from "./Gallery/Gallery";
import Contact from "./Contact/Contact";
import About from "./About/About";
import Meeting from "./Meeting&Events/Meeting";
import Rooms from "./Rooms/Rooms";



function App() {
  return (
    <>
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<Home />}></Route>
          <Route path="/home" element={<Home />}></Route>
          <Route path="/dinning" element={<Dinning />}></Route>
          <Route path="/gallery" element={<Gallery />}></Route>
          <Route path="/contact" element={<Contact />}></Route>
          <Route path="/about" element={<About />}></Route>
          <Route path="/meeting" element={<Meeting />}></Route>
          <Route path="/rooms" element={<Rooms />}></Route>
        </Routes>
      </BrowserRouter>
    </>
  );
}

export default App;
