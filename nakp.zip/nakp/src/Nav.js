import React, { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import logoH from './Home/Image/Dinning.png';
import './Home/css/Home.css'

function Nav() {
  const [scrolled, setScrolled] = useState(false);

  const handleScroll = () => {
    const offset = window.scrollY;
    if (offset > 100) {
      setScrolled(true);
    } else {
      setScrolled(false);
    }
  };

  useEffect(() => {
    window.addEventListener('scroll', handleScroll);
    return () => {
      window.removeEventListener('scroll', handleScroll);
    };
  }, []);
    return (
  <>

  <nav className={`navbar navbar-expand-lg fixed-top ${scrolled ? 'scrolled' : ''}`} >
  <div className="container">
    <Link className="navbar-brand" to="/home">
        <img alt='' src={logoH} style={{width:"100px"}} />
    </Link>
    <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
      <span className="navbar-toggler-icon"></span>
    </button>
    <div className="collapse navbar-collapse  align-items-center justify-content-center" id="navbarNav" >
      <ul className="navbar-nav ">
        <li className="nav-item ">
          <Link className="nav-link text-light "  to="/home">Home
          <span className='underline'></span>
          </Link>
        </li>
        <li className="nav-item">
          <Link to="/about" className="nav-link text-light">AboutUs
          <span className='underline'></span>
          </Link>
        </li>
        <li className="nav-item">
          <Link className="nav-link text-light" to="/rooms">Rooms
          <span className='underline'></span>
          </Link>
        </li>
        <li className="nav-item">
          <Link to="/dinning" className="nav-link text-light " >Dinning
          <span className='underline'></span>
          </Link>
        </li>
        <li className="nav-item">
          <Link to="/meeting" className="nav-link text-light " >Meeting & Events
          <span className='underline'></span>
          </Link>
        </li>
        <li className="nav-item">
          <Link to="/gallery" className="nav-link text-light" >Gallery
          <span className='underline'></span>
          </Link>
        </li>
        <li className="nav-item">
          <Link to="/contact" className="nav-link text-light" >Contact
          <span className='underline'></span>
          </Link>
        </li>
      </ul>
    </div>
  </div>
</nav>
  </>
       
    )
}

export default Nav