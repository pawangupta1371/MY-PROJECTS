import React from 'react'
import './css/Contact.css';
import Footer from '../Footer/Footer';
import Nav from '../Nav';
import Dinn from './Images/Dinning.png';

function Contact() {
    return (
        <>
            <Nav />
            <div className="px-4 py-5 text-center contact-background">
                <img className="d-block mx-auto mb-4" src={Dinn} alt="" style={{ width: "150px", height: "150px" }} />
                <h1 className="fs-3 fw-bold text-light text-uppercase" style={{ letterSpacing: '2px' }}>Contact</h1>
            </div>
            <div className='contact-bg'>
                <div className="container col-xxl-8 px-4 py-5">
                    <div className="row flex-lg-row-reverse align-items-center g-5 py-5">
                        <div className="col-10 col-sm-8 col-lg-6">
                            <h5 className='text-uppercase fw-bold'>Contact Information</h5>
                            <hr className='horziontal-line' style={{width: '80px'}} />
                            <div className='map-icon'>
                                <i className='fa fa-map-marker mx-4 text-warning' aria-hidden="true"></i>
                                <p className='d-inline-block text-secondary'>Beside WestChowk Road(Kholi Bypass Interchange)</p>
                            </div><br />
                            <div className='post-icon'>
                                <i className='fa fa-id-card mx-4 text-warning' aria-hidden="true"></i>
                                <p className='d-inline-block text-secondary'>P.O Box 249137 - 00506 NAP/k<sup>2</sup>,India</p>
                            </div><br />
                            <div className='envelope-icon'>
                                <i className='fa fa-envelope mx-4 text-warning'></i>
                                <p className='d-inline-block text-secondary'>napk@gmail.com</p>
                            </div><br />
                            <div className='telephone-icon'>
                                <i className='fa fa-phone mx-4 text-warning'></i>
                                <p className='d-inline-block text-secondary'>(+91)-8126703794, (+91)- 9997016650</p>
                            </div>
                        </div>
                        <div className="col-lg-6">
                            <h1 className="fs-2 fw-bold text-body-emphasis text-uppercase lh-1 mb-3">Leave Us Message</h1>
                            <hr className='horizontal-line text-dark' style={{width: '80px'}} />
                            <form>
                                <div className="form-floating mb-3">
                                    <input type="text" className="form-control" id="floatingInput" placeholder="For Example:John Smith" required />
                                    <label for="floatingInput">Full Name</label>
                                </div>
                                <div className="form-floating">
                                    <input type="email" className="form-control" id="floatingPassword" placeholder="johnsmith@gmail.com" required />
                                    <label for="floatingPassword">Email</label>
                                </div>
                                <div className="form-floating mb-3 mt-3">
                                    <input type="text" className="form-control" id="floatingInput2" placeholder="Short Topic/Description" required />
                                    <label for="floatingInput">Subject</label>
                                </div>
                                <div className="form-floating">
                                    <textarea className="form-control" id="floatingPassword2" rows="10" cols="50" placeholder="A Brief Description about the topic" required />
                                    <label for="floatingPassword">Message</label>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            <Footer />
        </>
    )
}

export default Contact;