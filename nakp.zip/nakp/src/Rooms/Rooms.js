import Footer from '../Footer/Footer';
import Nav from '../Nav';
import './css/Style.css';

function Rooms() {
    return (
        <>
        <Nav />
            <div className='room-bg'>

                <h3 className=" first" style={{ textAlign: "center", padding: "247px", color: "white", fontSize: "35px", }}> ROOMS </h3>

            </div>

            <div className='define' style={{ textAlign: 'center', margin: "45px" }}>
                <p style={{ color: "goldenrod", fontSize: "20px" }}> Accommodation at</p>
                <h2> NAP/K<sup>2</sup> PALACE</h2>
                <h6 style={{ padding: "20px" }}> AFFORDABLE COMFORT & CONVENIENCE</h6>
                <p>
                    NAP/K <sup>2</sup>  PALACE  rooms are designed to provide the highest levels of Comfort, Convenience and Eﬃciency, supported by the latest in technology.
                </p>
                <p>
                    The hotel has 167 air-conditioned rooms, of these 158 are Superior rooms, 2 rooms for guests with special needs, 3 triple rooms, 1 Junior<br /> Suite and 3 Executive Suites.
                    Guests staying in the Hotel have exclusive access to the gym and swimming pool.
                </p>

            </div>
            <br />
            <br />
            <br />
            <br />
            <div className='main' style={{ backgroundColor: "lightgray", margin: "5px", height: "450px", width: "100%" }}>

                <div className='container' style={{ display: "flex", justifyContent: "space-around" }}>
                    <div className='image' >
                        <img src="https://ekahotel.com/wp-content/uploads/2022/03/Superior-Room-2.jpg" alt='Room'
                            style={{ width: "85%",height:'99%', padding: "0px 0px 6px 0px" }} />

                    </div>
                    <div className='heading1' style={{ borderRight: "1px solid white", width: "25%", marginRight: "19px" }}>
                        <h3 style={{ padding: "15px", fontSize: '20 px' }}> SUPERIOR ROOM</h3>
                        <ul style={{ marginTop: "1px", lineHeight: "1.95" }}>
                            <li>Room size: 20 sq. m</li>
                            <li>LCD flat screen TV with DSTV</li>
                            <li>Beds: Double or Twin</li>
                            <li>King size bed</li>
                            <li>Complimentary Wi-Fi</li>
                            <li>Personal Minibar</li>
                            <li>Complimentary coffee making facilities</li>
                            <li>Direct dial International telephone</li>
                        </ul>
                    </div>
                    <div className='heading2' style={{ width: "25%", marginRight: "5px" }}>


                        <ul className='list2' style={{ lineHeight: "1.75", padding: "25px" }}>
                            <li>Hair driers, iron & board</li>
                            <li>Separate toilet and a rain shower</li>
                            <li>Safety deposit box</li>
                            <li>Non-smoking</li>
                            <li>2 rooms for guests with special needs</li>
                        </ul>
                        <div className="btnn2">
                            <button style={{ borderRadius: "22px", padding: "10px", fontSize: "18px" }}> Book Online</button>
                        </div>


                    </div>
                </div>

            </div>



            <div className='main2' style={{ backgroundColor: "whitesmoke", margin: "1px", height: "450px", width: "100%" }}>

                <div className='container' style={{ display: "flex", justifyContent: "space-around" }}>

                    <div className='heading1' style={{ borderRight: "1px solid white" }}>
                        <h3 style={{ padding: "20px", fontSize: '20 px' }}> JUNIOR SUITE</h3>
                        <ul style={{ marginTop: "1px", lineHeight: "1.99" }}>
                            <li  >Room size: 23 sq. m</li>
                            <li>LCD flat screen TV with DSTV</li>
                            <li>Beds: Double or Twin</li>
                            <li>King size bed</li>
                            <li>Complimentary Wi-Fi</li>
                            <li>Personal Minibar in the room</li>
                            <li>Complimentary coffee making facilities</li>
                            <li>Direct dial International <br />telephone</li>
                        </ul>

                    </div>
                    <div className='heading2'>
                        <ul className='list2' style={{ lineHeight: "1.99", padding: "25px" }}>
                            <li>Hair driers, iron & board</li>
                            <li>Separate toilet and a rain shower</li>
                            <li>Safety deposit box</li>
                            <li>Non-smoking</li>

                        </ul>
                        <div className="btnn1">
                            <button style={{ borderRadius: "22px", padding: "10px", fontSize: "18px" }}> Book Online</button>
                        </div>

                    </div>
                    <div className='imge' style={{ width: "580px", height: "750px" }} >
                        <img alt='room' src='https://assets-global.website-files.com/5c6d6c45eaa55f57c6367749/65045f093c166fdddb4a94a5_x-65045f0266217.webp'
                            style={{ width: "101%", height: "55%", padding: "10px" }} />

                    </div>
                </div>
            </div>
            <div>

                <div className='main3' style={{ backgroundColor: "lightgrey", margin: "5px", height: "450px", width: "100%" }}>

                    <div className='container' style={{ display: "flex", justifyContent: "space-around" }}>
                        <div className='image' >
                            <img src="http://cdn.luxuo.com/2017/05/rsz_hotel_92.jpg" alt='Room'
                                style={{ width: "84%", height: "115%", padding: "0px 0px 55px 0px" }} />
                        </div>
                        <div className='heading1' style={{ borderRight: "1px solid white", width: "25%", marginRight: "21px" }}>
                            <h3 style={{ padding: "20px", fontSize: '20 px' }}> SUPERIOR ROOM</h3>
                            <ul style={{ marginTop: "1px", lineHeight: "1.95" }}>
                                <li  >Room size: 20 sq. m</li>
                                <li>LCD flat screen TV with DSTV</li>
                                <li>Beds: Double or Twin</li>
                                <li>King size bed</li>
                                <li>Complimentary Wi-Fi</li>
                                <li>Personal Minibar</li>
                                <li>Complimentary coffee making facilities</li>
                                <li>Direct dial International telephone</li>
                            </ul>
                        </div>
                        <div className='heading2' style={{ width: "25%", marginRight: "5px" }}>
                            <ul className='list2' style={{ lineHeight: "1.75", padding: "25px" }}>
                                <li>Hair driers, iron & board</li>
                                <li>Separate toilet and a rain shower</li>
                                <li>Safety deposit box</li>
                                <li>Non-smoking</li>
                                <li>2 rooms for guests with special needs</li>
                            </ul>
                            <div className="btnn">
                                <button style={{ borderRadius: "22px", padding: "10px", fontSize: "18px" }}> Book Online</button>
                            </div>
                        </div>
                    </div>

                </div>





            </div>
            <Footer />
        </>
    )
}

export default Rooms;