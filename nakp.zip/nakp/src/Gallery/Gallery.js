
import Nav from '../Nav';
import Dinn from './Images/Dinning.png';
import './css/Gallery.css';
import Footer from '../Footer/Footer';
const Gallery = () => {

    const handleDownload = () => {
        const link = document.createElement('a');
        link.href = 'https://www.dropbox.com/s/skd4uxguqt39o77/Nature%20Photo%20Pack.zip?file_subpath=%2FNature+Photo+Pack';
        window.open(link, '_blank');
        link.download = 'file.pdf';
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    }

    return (
        <>
        <Nav />
            <div className="container-fluid">
                <div className="px-4 py-5 my-6 text-center gallery-background" >
                    <img className="d-block mx-auto mb-4" src={Dinn} alt="" style={{ width: "150px", height: "150px" }} />
                    <h1 className="fs-4 fw-bold text-light text-uppercase">Gallery</h1>
                </div>
            </div>
            <div className='container-fluid'>
                <div className='row gt-2' style={{padding: '90px 20px 20px 20px'}}>
                    <div className='col mt-4'>
                        <div className='col-content' style={{ marginRight: 'auto', marginLeft: 'auto' }}>
                            <div className="image-container">
                                <img src="https://ekahotel.com/wp-content/uploads/2022/04/19-pool-700x660.jpg" alt='dine_1' style={{ width: '280px', height: '300px' }} />
                                <div className="overlay">
                                    <i className="fa fa-search"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div className='col mt-4'>
                        <div className='col-content' style={{ marginRight: 'auto', marginLeft: 'auto' }}>
                            <div className="image-container">
                                <img src="https://ekahotel.com/wp-content/uploads/2022/04/09-bar-deck-700x660.jpg" alt='dine_3' style={{ width: '280px', height: '300px' }} />
                                <div className="overlay">
                                    <i className="fa fa-search"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div className='col mt-4'>
                        <div className='col-content' style={{ marginRight: 'auto', marginLeft: 'auto' }}>
                            <div className="image-container">
                                <img src="https://ekahotel.com/wp-content/uploads/2022/04/02-Lobby-700x660.jpg" alt='dine_3' style={{ width: '280px', height: '300px' }} />
                                <div className="overlay">
                                    <i className="fa fa-search"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div className='col mt-4'>
                        <div className='col-content' style={{ marginRight: 'auto', marginLeft: 'auto' }}>
                            <div className="image-container">
                                <img src="https://ekahotel.com/wp-content/uploads/2022/04/01-facade-700x660.jpg" alt='dine_3' style={{ width: '280px', height: '300px' }} />
                                <div className="overlay">
                                    <i className="fa fa-search"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                {/* Next section Gallery */}
                <div className='row gt-2' style={{padding: '10px 20px 20px 20px'}}>
                    <div className='col mt-4'>
                        <div className='col-content' style={{ marginRight: 'auto', marginLeft: 'auto' }}>
                            <div className="image-container">
                                <img src="https://ekahotel.com/wp-content/uploads/2022/04/23-meeting-room-700x660.jpg" alt='dine_1' style={{ width: '280px', height: '300px' }} />
                                <div className="overlay">
                                    <i className="fa fa-search"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div className='col mt-4'>
                        <div className='col-content' style={{ marginRight: 'auto', marginLeft: 'auto' }}>
                            <div className="image-container">
                                <img src="https://ekahotel.com/wp-content/uploads/2022/04/21-conference-foyer-700x660.jpg" alt='dine_3' style={{ width: '280px', height: '300px' }} />
                                <div className="overlay">
                                    <i className="fa fa-search"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div className='col mt-4'>
                        <div className='col-content' style={{ marginRight: 'auto', marginLeft: 'auto' }}>
                            <div className="image-container">
                                <img src="https://ekahotel.com/wp-content/uploads/2022/04/13-rooms-exec-700x660.jpg" alt='dine_3' style={{ width: '280px', height: '300px' }} />
                                <div className="overlay">
                                    <i className="fa fa-search"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div className='col mt-4'>
                        <div className='col-content' style={{ marginRight: 'auto', marginLeft: 'auto' }}>
                            <div className="image-container">
                                <img src="https://ekahotel.com/wp-content/uploads/2022/04/15-gym-700x660.jpg" alt='dine_3' style={{ width: '280px', height: '300px' }} />
                                <div className="overlay">
                                    <i className="fa fa-search"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                {/* Third Gallery Section */}
                <div className='row gt-2' style={{padding: '10px 20px 20px 20px'}}>
                    <div className='col mt-4'>
                        <div className='col-content' style={{ marginRight: 'auto', marginLeft: 'auto' }}>
                            <div className="image-container">
                                <img src="https://ekahotel.com/wp-content/uploads/2022/04/16-massage-room-700x660.jpg" alt='dine_1' style={{ width: '280px', height: '300px' }} />
                                <div className="overlay">
                                    <i className="fa fa-search"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div className='col mt-4'>
                        <div className='col-content' style={{ marginRight: 'auto', marginLeft: 'auto' }}>
                            <div className="image-container">
                                <img src="https://ekahotel.com/wp-content/uploads/2022/04/18-pool-700x660.jpg" alt='dine_3' style={{ width: '280px', height: '300px' }} />
                                <div className="overlay">
                                    <i className="fa fa-search"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div className='col mt-4'>
                        <div className='col-content' style={{ marginRight: 'auto', marginLeft: 'auto' }}>
                            <div className="image-container">
                                <img src="https://ekahotel.com/wp-content/uploads/2022/04/20-pool-side-garden-700x660.jpg" alt='dine_3' style={{ width: '280px', height: '300px' }} />
                                <div className="overlay">
                                    <i className="fa fa-search"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div className='col mt-4'>
                        <div className='col-content' style={{ marginRight: 'auto', marginLeft: 'auto' }}>
                            <div className="image-container">
                                <img src="https://ekahotel.com/wp-content/uploads/2022/04/22-meeting-room-700x660.jpg" alt='dine_3' style={{ width: '280px', height: '300px' }} />
                                <div className="overlay">
                                    <i className="fa fa-search"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                {/* Fourth Gallery Section */}
                <div className='row gt-2' style={{padding: '10px 20px 20px 20px'}}>
                    <div className='col mt-4'>
                        <div className='col-content' style={{ marginRight: 'auto', marginLeft: 'auto' }}>
                            <div className="image-container">
                                <img src="https://ekahotel.com/wp-content/uploads/2022/04/25-meeting-room-700x660.jpg" alt='dine_1' style={{ width: '280px', height: '300px' }} />
                                <div className="overlay">
                                    <i className="fa fa-search"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div className='col mt-4'>
                        <div className='col-content' style={{ marginRight: 'auto', marginLeft: 'auto' }}>
                            <div className="image-container">
                                <img src="https://ekahotel.com/wp-content/uploads/2022/04/27-gift-shop-700x660.jpg" alt='dine_3' style={{ width: '280px', height: '300px' }} />
                                <div className="overlay">
                                    <i className="fa fa-search"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div className='col mt-4'>
                        <div className='col-content' style={{ marginRight: 'auto', marginLeft: 'auto' }}>
                            <div className="image-container">
                                <img src="https://ekahotel.com/wp-content/uploads/2022/04/03-restaurant-700x660.jpg" alt='dine_3' style={{ width: '280px', height: '300px' }} />
                                <div className="overlay">
                                    <i className="fa fa-search"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div className='col mt-4'>
                        <div className='col-content' style={{ marginRight: 'auto', marginLeft: 'auto' }}>
                            <div className="image-container">
                                <img src="https://ekahotel.com/wp-content/uploads/2022/04/04-coffee-shop-700x660.jpg" alt='dine_3' style={{ width: '280px', height: '300px' }} />
                                <div className="overlay">
                                    <i className="fa fa-search"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                {/* Fifth Gallery Section */}
                <div className='row gt-2' style={{padding: '10px 20px 20px 20px'}}>
                    <div className='col mt-4'>
                        <div className='col-content' style={{ marginRight: 'auto', marginLeft: 'auto' }}>
                            <div className="image-container">
                                <img src="https://ekahotel.com/wp-content/uploads/2022/04/05-coffee-shop-700x660.jpg" alt='dine_1' style={{ width: '280px', height: '300px' }} />
                                <div className="overlay">
                                    <i className="fa fa-search"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div className='col mt-4'>
                        <div className='col-content' style={{ marginRight: 'auto', marginLeft: 'auto' }}>
                            <div className="image-container">
                                <img src="https://ekahotel.com/wp-content/uploads/2022/04/06-bar-700x660.jpg" alt='dine_3' style={{ width: '280px', height: '300px' }} />
                                <div className="overlay">
                                    <i className="fa fa-search"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div className='col mt-4'>
                        <div className='col-content' style={{ marginRight: 'auto', marginLeft: 'auto' }}>
                            <div className="image-container">
                                <img src="https://ekahotel.com/wp-content/uploads/2022/04/07-bar-700x660.jpg" alt='dine_3' style={{ width: '280px', height: '300px' }} />
                                <div className="overlay">
                                    <i className="fa fa-search"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div className='col mt-4'>
                        <div className='col-content' style={{ marginRight: 'auto', marginLeft: 'auto' }}>
                            <div className="image-container">
                                <img src="https://ekahotel.com/wp-content/uploads/2022/04/08-bar-deck-700x660.jpg" alt='dine_3' style={{ width: '280px', height: '300px' }} />
                                <div className="overlay">
                                    <i className="fa fa-search"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div className='container mt-4 mb-4'>
                <div className='text-center'>
                    <button className='btn btn-warning btn-lg' onClick={handleDownload}>
                        Download High Resolution Photos
                    </button>
                </div>
            </div>
            <Footer />
        </>
    )
}

export default Gallery;