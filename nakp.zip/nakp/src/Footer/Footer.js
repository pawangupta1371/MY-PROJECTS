import React from 'react'
import './css/Footer.css';
import Dinn from './Images/Dinning.png';
import { Link } from 'react-router-dom';

function Footer() {
    return (
        <>
            <div className="container-fluid footercolor">
                <footer className="row row-cols-1 row-cols-sm-2 row-cols-md-5 px-5 py-5 border-top">
                    <div className="col mb-3">
                        <p className='fs-5 fw-bold text-warning text-uppercase'>
                            Call Us
                        </p>
                        <Link href="/" className="d-flex align-items-center mb-3 link-body-emphasis text-decoration-none text-light">
                            <i className='fa fa-phone text-warning mx-4 fs-4'></i>
                            (+91)-8126703794
                        </Link>
                        <p className='fs-5 fw-bold text-warning text-uppercase'>
                            Email
                        </p>
                        <Link href="/" className="d-flex align-items-center mb-3 link-body-emphasis text-decoration-none text-light">
                            napkpalace@gmail.com
                        </Link>
                    </div>

                    <div className="col mb-3">

                    </div>

                    <div className="col mb-3">
                        <h5 className='text-warning'>About Us</h5>
                        <ul className="foot-nav nav flex-column">
                            <li className=" nav-item mb-2"><Link to="/home" className="footer-nav nav-link p-2" style={{ borderLeft: '2px solid lightgrey', height: '35px', borderBottom: '1px solid white', color: 'lightgrey', fontSize: '16px' }}>Home</Link></li>
                            <li className=" nav-item mb-2"><Link to="/offers" className="footer-nav nav-link p-2" style={{ borderLeft: '2px solid lightgrey', height: '35px', borderBottom: '1px solid white', color: 'lightgrey', fontSize: '16px' }}>Offers</Link></li>
                            <li className=" nav-item mb-2"><Link to="/gallery" className="footer-nav nav-link p-2" style={{ borderLeft: '2px solid lightgrey', height: '35px', borderBottom: '1px solid white', color: 'lightgrey', fontSize: '16px' }}>Gallery</Link></li>
                        </ul>
                    </div>

                    <div className="col mb-3">
                        <h5 className='text-warning'>Quick Links</h5>
                        <ul className="foot-nav nav flex-column">
                            <li className=" nav-item mb-2"><Link to="/rooms" className="footer-nav nav-link p-2" style={{ borderLeft: '2px solid lightgrey', height: '35px', borderBottom: '1px solid white', color: 'lightgrey', fontSize: '16px' }}>Rooms</Link></li>
                            <li className=" nav-item mb-2"><Link to="/dinning" className="footer-nav nav-link p-2" style={{ borderLeft: '2px solid lightgrey', height: '35px', borderBottom: '1px solid white', color: 'lightgrey', fontSize: '16px' }}>Dinning Experience</Link></li>
                            <li className=" nav-item mb-2"><Link to="/meeting" className="footer-nav nav-link p-2" style={{ borderLeft: '2px solid lightgrey', height: '35px', borderBottom: '1px solid white', color: 'lightgrey', fontSize: '16px' }}>Meeting & Events</Link></li>
                        </ul>
                    </div>

                    <div className="col mb-3">
                        <img className="d-block mx-auto" src={Dinn} alt="" style={{ width: "80px", height: "80px" }} />
                        <p className='fs-6 fw-large text-light'>
                            Still wondering where to find peace ?<br />
                            Don't worry you will always be our <b>'FIRST PRIORITY'</b>
                        </p>
                    </div>
                </footer>
            </div>
            <div className='footerflex bg-warning'>
                <div className='leftflex text-light'>
                    @2023 NAPK/<sup>2</sup> Palace, All Rights Reserved.
                </div>
                <div className='rightflex'>
                    <p className='mt-3 text-light'>
                        Follow us on
                        <Link className='text-decoration-none text-light' target='_blank' to="https://www.instagram.com/">
                          <i className='fa fa-instagram'></i>
                        </Link>
                        <Link className='text-decoration-none text-light' target='_blank' to="https://www.facebook.com/">
                            <i className='fa fa-facebook'></i>
                        </Link>
                        <Link className='text-decoration-none text-light' target='_blank' to="https://www.twitter.com/">
                            <i className='fa fa-twitter'></i>
                        </Link>
                    </p>
                </div>
            </div>
        </>
    )
}

export default Footer