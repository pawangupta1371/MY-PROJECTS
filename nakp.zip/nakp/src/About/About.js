import React from "react";
import "./css/About.css";
import Dinn from "./Images/DinningBlack.png";
import Nav from "../Nav";
import Footer from "../Footer/Footer";



function About() {
    return (
        <>
            <Nav />
            <div className="px-4 py-5 text-center about">
                <img
                    className="d-block mx-auto mb-4 mt-5"
                    src={Dinn}
                    alt=""
                    width="74px"
                    height="60px"
                />
                <h1 className="display-5 fw-bold fs-3 text-body-emphasis">ABOUT US</h1>
            </div>
            <div>
                <h1 className="Eka">Eka Hotel Nairobi</h1>
            </div>
            <div>
                <p className="color">Comfort & Convenience at ...the Only One!</p>
            </div>
            <div>
                <p className="page">
                    Welcome to Eka, a contemporary style hotel that provides all the
                    comfort, convenience and efficiency to the discerning traveler.
                    Ideally located along Mombasa road in Nairobi the capital city of
                    Kenya, Eka Hotel Nairobi features 167 well-appointed rooms, five
                    meeting & conference rooms, restaurant & bar, gym, swimming pool, gift
                    shop, wellness center among other top facilities offering the best
                    choice venue for your Business
                </p>
            </div>
            <div><button className="but">BOOK NOW</button></div>

            <div className="flex">
                <div> <img
                    className="box" src="https://ekahotel.com/wp-content/uploads/2022/03/about-us-bg-2.jpg" alt="" width="72" height="57" />
                </div>
                <div className="cen">
                    <div className="our">
                        <h2>Our Mission</h2>
                        <br />
                        <p className="paag" >To acquire the loyalty of our clients by exceeding their expectations in offering comfort, convenience and efficient services.</p>
                    </div>
                    <div className="our">
                        <h2>Vision</h2>
                        <br />
                        <p className="paag">To acquire the loyalty of our clients by exceeding their expectations in offering comfort, convenience and efficient services.</p>
                    </div>
                    <div className="our">
                        <h2 className="core">Core Values</h2>
                        <br />
                        <p className="paag">To acquire the loyalty of our clients by exceeding their expectations in offering comfort, convenience and efficient services.</p>
                    </div>
                </div>
            </div>

            <div className="back">

                <div id="home">
                    <div>
                        <h5>LOCATION</h5>
                        <br />
                        <p>Along Mombasa road with<br /> easy access to both Jomo<br /> Kenyatta International Airport <br />and Wilson Airport.</p>
                    </div>
                    <div>
                         <h5>SERVICE</h5>
                        <br />
                        <p>Along Mombasa road with<br /> easy access to both Jomo<br /> Kenyatta International Airport <br />and Wilson Airport.</p>
                    </div>
                    <div> <h5>AFFORDABILITY</h5>
                        <br />
                        <p>Along Mombasa road with<br /> easy access to both Jomo<br /> Kenyatta International Airport <br />and Wilson Airport.</p>
                    </div>
                    <div> <h5>REVIEWS</h5>
                        <br />
                        <p>Along Mombasa road with<br /> easy access to both Jomo<br /> Kenyatta International Airport <br />and Wilson Airport.</p>
                    </div>
                    <div> <h5>TECHNOLOGY</h5>
                        <br />
                        <p>Along Mombasa road with<br /> easy access to both Jomo<br /> Kenyatta International Airport <br />and Wilson Airport.</p>
                    </div>
                </div>
            </div>
            <div className="social">
                <h1>Corporate Social Responsibility</h1>
            </div>
            <div className="hotel">
                <p>Eka Hotel is affiliated with the Amrit Foundation.The Hotel and the Foundation continuously  support various CSR initiative as a way of giving back to society, in line with the companies’ <br />Sustainable Development Goals.</p>
            </div>
            <div className="hotel">
                <p>To participate in any of noble causes,,<span> contact us </span>or reach out to the <span>Amrit Foundation Trust</span> and we will be more than happy to provide further details and <br />information.</p>
            </div>
            <div><button className="but">Read More About our Us</button></div>

            <div className="social">
                <h1>Eka Hotel Enviromental Policy</h1>
            </div>
            <div className="hotel">
                <p>In tandem with our vision “To acquire the loyalty of our clients by exceeding their expectations in offering comfort, convenience and efficient services.” we are committed to continually improving the environmental that we operate in as well as ensuring social sustainability. Eka Hotel identifies and refines existing policies clearly following the standards,<br /> legislation and bench-marking of third-party authorities.</p>
            </div>
            <Footer />
        </>
    );
}

export default About;