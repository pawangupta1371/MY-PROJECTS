import { Link } from "react-router-dom";
import Nav from "../Nav";
import Dinn from './Images/Dinning.png';
import './css/Meeting.css';
import Footer from '../Footer/Footer';

const Meeting = () => {

    const handleDownload = () => {
        const link = document.createElement('a');
        link.href = 'https://ataliganga.com/wp-content/uploads/2022/09/Atali-Fact-Sheet.pdf';
        window.open(link, '_blank');
        link.download = 'file.pdf';
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    }

    return (
        <>
            <Nav />
            <div className="px-4 py-5 text-center Meeting-background">
                <img className="d-block mx-auto mb-4" src={Dinn} alt="" style={{ width: "150px", height: "150px" }} />
                <h1 className="display-5 fw-bold text-light text-uppercase">Meeting & Events</h1>
            </div>
            <div className="container-fluid col-xxl-8 px-4 py-5">
                <div className="row flex-lg-row-reverse align-items-center g-6 py-5">
                    <div className="col-10 col-sm-8 col-lg-6">
                        <p className="fs-6 fw-large text-secondary">
                            Located on the ground ﬂoor and the ﬁrst ﬂoor, the fully serviced and air-conditioned multi-functional three<br /> meeting rooms
                            and two boardrooms cater for up to 200 people theatre style and can be adapted to suit the speciﬁc needs of our guests.<br /><br />

                            All meeting rooms feature the latest technology with complete range of support services including a<br /> business center.
                        </p>
                    </div>
                    <div className="col-lg-6">
                        <p className="text-warning ">Meeting New Expectations !</p>
                        <h1 className="display-6 fw-bold text-body-emphasis lh-1 mb-3">Meetings, Conferences
                            and Events in NAP/K<sup>2</sup> Palace</h1>
                    </div>
                </div>
            </div>
            <div className="gdlr-core-title-item text-center gdlr-core-item-pdb clearfix  gdlr-core-center-align gdlr-core-title-item-caption-top gdlr-core-item-pdlr mt-4">
                <div className="gdlr-core-title-item-title-wrap">
                    <h3 className="gdlr-core-title-item-title gdlr-core-skin-title" style={{ fontSize: "35px", letterSpacing: "0px", TextTransform: "none" }}>
                        Meeting Rooms Configuration
                        <span className="gdlr-core-title-item-title-divider gdlr-core-skin-divider"></span>
                    </h3>
                </div>
            </div>
            <div className="gdlr-core-pbf-element">
                <div className="gdlr-core-text-box-item gdlr-core-item-pdlr gdlr-core-item-pdb gdlr-core-center-align" style={{ paddingBottom: "20px" }}>
                    <div className="gdlr-core-text-box-item-content text-center mt-3 text-secondary " style={{ fontSize: "18px", textTransform: "none" }}>
                        <p className="text-secondary">
                            All meeting and event venues are equipped with LCD projector, Flat screen TVs, Laser pointer, Air-condition units,<br />
                            Black-out sheers & curtains and Wi-ﬁ hot spots.
                        </p>
                    </div>
                </div>
            </div>
            <div className="gdlr-core-pbf-element mb-5">
                <div className="gdlr-core-divider-item gdlr-core-divider-item-small-center gdlr-core-item-pdlr">
                    <div className="gdlr-core-divider-container" style={{ maxWidth: "80px" }}>
                        <div className="gdlr-core-divider-line gdlr-core-skin-divider" style={{ borderColor: "#b78e00 " }}>
                            <div className="gdlr-core-divider-line-bold  gdlr-core-skin-divider " style={{ borderColor: "#b78e00" }}></div>
                        </div>
                    </div>
                </div>
            </div>
            <section id="gallery">
                <div className="container">
                    <div className="row">
                        <div className="col-lg-4 mb-4 col-content">
                            <div className="frame">
                                <div className="card" style={{ padding: '50px 50px 50px 50px' }}>
                                    <div className="image-container">
                                        <img src="https://ekahotel.com/wp-content/uploads/2022/06/Eka-Hotel-Meeting-Rooms-left.jpg" alt="" className="card-img-top" />
                                        <div className="overlay">
                                            <i className="fa fa-search"></i>
                                        </div>
                                    </div>
                                    <div className="card-body text-center">
                                        <i className=" fs-4  text-warning fa fa-bars mb-3"></i>
                                        <h5 className="card-title">Sunset</h5>
                                        <p className="card-text text-secondary">Location: 1st Floor<br />
                                            Size:13.8 m x 13.8 m (190 m²)<br />
                                            Capacity (pax): 40 min, 200 max<br />
                                            *Capacity depends on seating<br /> configuration.
                                        </p>
                                        <Link to="" className="btn btn-outline-success btn-sm mx-2">Read More</Link>
                                        <Link to="" className="btn btn-outline-danger btn-sm"><i className="fa fa-heart"></i></Link>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div className="col-lg-4 mb-4 col-content">
                            <div className="frame">
                                <div className="card" style={{ padding: '50px 50px 50px 50px' }}>
                                    <div className="image-container">
                                        <img src="https://ekahotel.com/wp-content/uploads/2022/03/Lilium-Rosa-Meeting-Room-Eka-Hotel-Nairobi.jpg" alt="" className="card-img-top" />
                                        <div className="overlay">
                                            <i className="fa fa-search"></i>
                                        </div>
                                    </div>
                                    <div className="card-body text-center">
                                        <i className=" fs-4  text-warning fa fa-bars mb-3"></i>
                                        <h5 className="card-title">Lilium/Rosa</h5>
                                        <p className="card-text text-secondary">Location: Ground Floor<br />
                                            Size:6.8 m x 6.8 m (46 m²)<br />
                                            Capacity (pax): 15 min, 30 max<br />
                                            *Capacity depends on seating<br /> configuration.
                                        </p>
                                        <Link to="" className="btn btn-outline-success btn-sm mx-2">Read More</Link>
                                        <Link to="" className="btn btn-outline-danger btn-sm"><i className="fa fa-heart"></i></Link>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div className="col-lg-4 mb-4 col-content">
                            <div className="frame">
                                <div className="card" style={{ padding: '50px 50px 50px 50px' }}>
                                    <div className="image-container">
                                        <img src="https://ekahotel.com/wp-content/uploads/2022/03/Salvia-Meeting-Room-Eka-Hotel-Nairobi.jpg" alt="" className="card-img-top" />
                                        <div className="overlay">
                                            <i className="fa fa-search"></i>
                                        </div>
                                    </div>
                                    <div className="card-body text-center">
                                        <i className=" fs-4  text-warning fa fa-bars mb-3"></i>
                                        <h5 className="card-title">Salvia/Alpinia</h5>
                                        <p className="card-text text-secondary">Location: Ground Floor<br />
                                            Size:4.8 m x 7.2 m (35 m²)<br />
                                            Capacity (pax): 8 min, 15 max<br />
                                            *Capacity Based on Broadroom Seating<br /> Style.
                                        </p>
                                        <Link to="" className="btn btn-outline-success btn-sm mx-2">Read More</Link>
                                        <Link to="" className="btn btn-outline-danger btn-sm"><i className="fa fa-heart"></i></Link>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <div className="meeting-fixed-background">
                <div className="container px-4 py-5" id="hanging-icons">
                    <div className="row g-4 py-5 row-cols-1 row-cols-lg-3">
                        <div className=" meeting-vertical-lists col d-flex align-items-start">
                            <div>
                                <h3 className="fs-2 text-light">Why Book you next event with us ?</h3>
                                <Link to="#" className="btn btn-warning mt-4" onClick={handleDownload}>
                                    <i className="fa fa-download" style={{ marginRight: '8px' }}></i>
                                    View Sales / Banqueting Kit
                                </Link>
                            </div>
                            <div className="meeting-vertical-line"></div>
                        </div>
                        <div className=" meeting-vertical-lists col d-flex align-items-start">
                            <div className="icon-square text-body-emphasis bg-body-secondary d-inline-flex align-items-center justify-content-center fs-4 flex-shrink-0 me-3">
                            </div>
                            <div>
                                <h3 className="fs-5 text-light">
                                    <div className="d-inline-block mx-2">
                                        <i className="text-warning fa fa-dollar"></i>
                                    </div>
                                    Affordability & Flexibility
                                </h3>
                                <p className=" fs-5 text-light mt-4">We offer our meeting and conference facility at competitive rates without compromising on quality.</p>
                            </div>
                            <div className="meeting-vertical-line"></div>
                        </div>
                        <div className=" col d-flex align-items-start">
                            <div className="icon-square text-body-emphasis bg-body-secondary d-inline-flex align-items-center justify-content-center fs-4 flex-shrink-0 me-3">
                            </div>
                            <div>
                                <h3 className="fs-5 text-light">

                                    <div className="d-inline-block mx-2">
                                        <i className="text-warning fa fa-user"></i>
                                    </div>

                                    Dedicated Team</h3>
                                <p className="fs-5 text-light mt-4">
                                    There is always a dedicated banqueting team available for every event/meeting that you will host at NAP/K<sup>2</sup> Palace, to ensure a successful function.
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div className="container-fluid col-xxl-8 px-4 py-5 meet-event-background">
                <div className="row flex-lg-row-reverse align-items-center g-5 py-5">
                    <div className="col-lg-6" style={{ padding: "90px 40px 0px 60px", marginTop: '-120px' }}>
                        <div className="gdlr-core-title-item text-center gdlr-core-item-pdb clearfix  gdlr-core-center-align gdlr-core-title-item-caption-top gdlr-core-item-pdlr mt-4">
                            <div className="gdlr-core-title-item-title-wrap">
                                <h3 className="gdlr-core-title-item-title gdlr-core-skin-title" style={{ fontSize: "35px", letterSpacing: "0px", TextTransform: "none" }}>
                                    Outside Catering & Office Deliveries
                                    <span className="gdlr-core-title-item-title-divider gdlr-core-skin-divider"></span>
                                </h3>
                            </div>
                        </div>
                        <div className="gdlr-core-pbf-element mb-5">
                            <div className="gdlr-core-divider-item gdlr-core-divider-item-small-center gdlr-core-item-pdlr">
                                <div className="gdlr-core-divider-container" style={{ maxWidth: "80px" }}>
                                    <div className="gdlr-core-divider-line gdlr-core-skin-divider" style={{ borderColor: "#b78e00 " }}>
                                        <div className="gdlr-core-divider-line-bold  gdlr-core-skin-divider " style={{ borderColor: "#b78e00" }}></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div className="gdlr-core-pbf-element">
                            <div className="gdlr-core-text-box-item gdlr-core-item-pdlr gdlr-core-item-pdb gdlr-core-center-align" style={{ paddingBottom: "20px" }}>
                                <div className="gdlr-core-text-box-item-content text-center mt-3 text-secondary " style={{ fontSize: "18px", textTransform: "none" }}>
                                    <p className="text-secondary">
                                        We are committed to taking care of your banqueting needs to allow you focus on your event; whether a full-day meeting, luncheon or cocktail.<br /><br/>
                                        With our dedicated service team with vast experience and a fully-equipped outside catering vehicle, you can trust us to deliver divine memories.
                                    </p>
                                </div>
                            </div>
                        </div>
                        <div className="text-center">
                            <Link to="#" className=" fs-5 btn btn-warning">
                                T: (+91)-8126703794/ E: paradisepalace@gmail.com
                            </Link>
                        </div>
                    </div>
                    <div className="col-10 col-sm-8 col-lg-6">
                        <div className='meeting-background-wrapper' style={{ color: '#ffff', marginTop: '-65px', marginLeft: '-40px' }}>
                            <div className='meeting-events-background-image'></div>
                        </div>
                    </div>
                </div>
            </div>
            <Footer/>
        </>
    )

}

export default Meeting;