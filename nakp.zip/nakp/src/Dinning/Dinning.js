import './Css/Dinning.css';
import Dinn from './Images/Dinning.png'
import DinnBlack from './Images/DinningBlack.png';
import Dinn1 from './Images/Dine_1.webp';
import Dinn2 from './Images/Dine_2.webp';
import Dinn3 from './Images/Dine_3.webp';
import Footer from '../Footer/Footer';
import { useState } from 'react';
import { Link } from 'react-router-dom';
import Nav from '../Nav';


const Dinning = () => {

    const [isFlipped, setIsFlipped] = useState(false);

    const handleFlip = () => {
        setIsFlipped(!isFlipped);
    };

    const handleDownload = () => {
        const link = document.createElement('a');
        link.href = 'https://www.tajhotels.com/content/dam/luxury/hotels/taj-rishikesh/menus/Rockflour%20Menu.pdf';
        window.open(link, '_blank');
        link.download = 'file.pdf';
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    }

    return (
        <>
        <Nav />
            <div className="px-4 py-5 text-center dinning-background">
                <img className="d-block mx-auto mb-4" src={Dinn} alt="" style={{ width: "150px", height: "150px" }} />
                <h1 className="display-5 text-light text-uppercase">Dinning</h1>
                <div className="col-lg-6 mx-auto">
                    <p className="text-bold text-light  mb-4">
                        Where flavor meets elegance,
                        every meal is a celebration.
                    </p>
                </div>
            </div>
            <div className="gdlr-core-title-item text-center gdlr-core-item-pdb clearfix  gdlr-core-center-align gdlr-core-title-item-caption-top gdlr-core-item-pdlr mt-4">
                <span className="gdlr-core-title-item-caption gdlr-core-info-font gdlr-core-skin-caption" style={{ fontSize: "22px", fontStyle: "normal", color: "#b78e00" }}>
                    Divine &amp; Delactable
                </span>
                <div className="gdlr-core-title-item-title-wrap">
                    <h3 className="gdlr-core-title-item-title gdlr-core-skin-title" style={{ fontSize: "35px", letterSpacing: "0px", TextTransform: "none" }}>
                        Dining Experience at NAKP Palace
                        <span className="gdlr-core-title-item-title-divider gdlr-core-skin-divider"></span>
                    </h3>
                </div>
            </div>
            <div className="gdlr-core-pbf-element">
                <div className="gdlr-core-divider-item gdlr-core-divider-item-small-center gdlr-core-item-pdlr">
                    <div className="gdlr-core-divider-container" style={{ maxWidth: "80px" }}>
                        <div className="gdlr-core-divider-line gdlr-core-skin-divider" style={{ borderColor: "#b78e00 " }}>
                            <div className="gdlr-core-divider-line-bold  gdlr-core-skin-divider mt-3" style={{ borderColor: "#b78e00" }}></div>
                        </div>
                    </div>
                </div>
            </div>
            <div className="gdlr-core-pbf-element">
                <div className="gdlr-core-text-box-item gdlr-core-item-pdlr gdlr-core-item-pdb gdlr-core-center-align" style={{ paddingBottom: "20px" }}>
                    <div className="gdlr-core-text-box-item-content text-center mt-3 text-secondary " style={{ fontSize: "18px", textTransform: "none" }}>
                        <p>
                            NAKP Palace has continued to stirred up the local culinary scene with two restaurants,
                            two bars and a 24-hr coffee shop that cater to the<br /> needs of our diverse clientele,
                            offering delectable experiences and divine memories. Each dining experience provides our guests with a taste of
                            a<br /> broad selection of international and local cuisine.
                        </p>
                    </div>
                </div>
            </div>
            <div className='wrapper' style={{ padding: '50px 80px 30px 80px' }}>
                <div className='background-wrapper' style={{ color: '#ffff' }}></div>
                <div className='wrapper-content overdisplay'>
                    <div className='row gt-2'>
                        <div className='col'>
                            <div className='col-content' style={{ marginRight: 'auto', marginLeft: 'auto' }}>
                                <div className="image-container">
                                    <img src={Dinn1} alt='dine_1' style={{ width: '300px', height: '440px' }} />
                                    <div className="overlay">
                                        <i className="fa fa-search"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div className='col'>
                            <div className='col-content' style={{ marginRight: 'auto', marginLeft: 'auto' }}>
                                <div className="image-container">
                                    <img src={Dinn2} alt='dine_3' style={{ width: '300px', height: '440px' }} />
                                    <div className="overlay">
                                        <i className="fa fa-search"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div className='col'>
                            <div className='col-content' style={{ marginRight: 'auto', marginLeft: 'auto' }}>
                                <div className="image-container">
                                    <img src={Dinn3} alt='dine_3' style={{ width: '300px', height: '440px' }} />
                                    <div className="overlay">
                                        <i className="fa fa-search"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div className="container-fluid col-xxl-8 px-3 py-5" >
                <div className="row flex-lg-row-reverse align-items-center">
                    <div className="col-lg-6">
                        <div className='column-background-wrapper'>
                            <div className='column-background'>
                                <div className="column-content">
                                    <div className={`flip-container ${isFlipped ? 'hover' : ''}`} onMouseEnter={handleFlip} onMouseLeave={handleFlip}>
                                        <div className="flipper">
                                            <div className="front">
                                                <h1 className="display-6 text-uppercase fw-bold text-secondary" style={{ marginLeft: '20px', marginBottom: '30px' }}>Galaxy Restaurants</h1>
                                                <div className="col mx-4">
                                                    <p className="mb-4" style={{ lineHeight: '2rem' }}>
                                                        Eka Hotel offers dining at its best with the freshest flavors of locally sourced produce. It offers a
                                                        selected buffet breakfast, all-day a-la-carte and snack dining, flowing coffee/tea dispenser, and 24-hour
                                                        room service.
                                                        <br />
                                                        <br />
                                                        Spread out over the ground floor, the Galaxy (150 covers) showcases the finest cuisine, complete with live
                                                        show kitchen and an outdoor terrace overlooking the pool.
                                                    </p>
                                                    <div className="d-grid d-sm-flex justify-content-sm-center">
                                                        <button type="button" className="btn btn-warning px-3 gap-3" style={{ padding: '10px 10px', color: 'white' }}>
                                                            <i className='fa fa-download' style={{ color: 'black', marginRight: '8px' }}></i>
                                                            VIEW MENU
                                                        </button>
                                                    </div>
                                                </div>
                                            </div>
                                            <div className="dinning-back d-flex flex-column justify-content-center align-items-center">
                                                <i style={{ fontFamily: "serif" }}>
                                                    <p style={{ textAlign: 'center', fontSize: '35px', marginTop: '220px', textTransform: 'uppercase' }}>
                                                        "
                                                        Don't leave Anything here <br />
                                                        Except your Compilments
                                                        "
                                                    </p>
                                                </i>
                                                <button type='submit' className='btn btn-warning bt-lg my-3 text-light' onClick={handleDownload}>
                                                    <i className='fa fa-download' style={{ color: 'black', marginRight: '8px' }}></i>
                                                    VIEW MENU
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div className="col-10 col-sm-8 col-lg-6">
                        <div className='background-wrapper'>
                            <div className='galaxy-background-image'></div>
                        </div>
                    </div>
                </div>
            </div>
            <div className="container-fluid" >
                <div className="row flex-lg-row-reverse align-items-center">
                    <div className="col-10 col-sm-8 col-lg-6">
                        <div className='background-wrapper' style={{ marginLeft: '-24px', marginTop: '-45px' }}>
                            <div className='background-image2'></div>
                        </div>
                    </div>
                    <div className="col-lg-6">
                        <div className='column-background-wrapper'>
                            <div className='column-background'>
                                <div className="column-content">
                                    <div className={`flip-container ${isFlipped ? 'hover' : ''}`} onMouseEnter={handleFlip} onMouseLeave={handleFlip}>
                                        <div className="flipper">
                                            <div className="front" style={{ lineHeight: '1.7' }}>
                                                <h1 className="display-6 text-uppercase fw-bold text-secondary" style={{ marginLeft: '20px', marginBottom: '30px' }}>Galaxy Coffee Shop</h1>
                                                <div className="col mx-4">
                                                    <p className="mb-4">
                                                        Open 24 hrs, the coffee shop is ideal for casual meetings with family or friends. <br />
                                                        Brace yourself to be delighted by a wide selection of high quality coffee & tea blends,
                                                        beverages and tasty meals to suit your taste.<br /><br />

                                                        Our experienced barista will not only brew coffee that will warm your heart but also serve it with freshly
                                                        baked cakes and pastries, the best way to get your daily grind going.
                                                    </p>
                                                    <div className="d-grid d-sm-flex justify-content-sm-center">
                                                        <button type="button" className="btn btn-warning px-3 gap-3" style={{ padding: '10px 10px', color: 'white' }}>
                                                            <i className='fa fa-download' style={{ color: 'black', marginRight: '8px' }}></i>
                                                            VIEW MENU
                                                        </button>
                                                    </div>
                                                </div>
                                            </div>
                                            <div className="dinning-back d-flex flex-column justify-content-center align-items-center">
                                                <i style={{ fontFamily: "serif" }}>
                                                    <p style={{ textAlign: 'center', fontSize: '35px', marginTop: '220px', textTransform: 'uppercase' }}>
                                                        "
                                                        We don't encourage Rumours <br />
                                                        unless they are POSITIVE
                                                        "
                                                    </p>
                                                    <button type="button" className="btn btn-warning btn-lg my-6 text-light" onClick={handleDownload}>
                                                        <i className='fa fa-download' style={{ color: 'black', marginRight: '8px' }}></i>
                                                        VIEW MENU
                                                    </button>
                                                </i>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div className="container-fluid col-xxl-8 px-3 py-5" >
                <div className="row flex-lg-row-reverse align-items-center">
                    <div className="col-lg-6">
                        <div className='column-background-wrapper'>
                            <div className='column-background'>
                                <div className="column-content">
                                    <div className={`flip-container ${isFlipped ? 'hover' : ''}`} onMouseEnter={handleFlip} onMouseLeave={handleFlip}>
                                        <div className="flipper">
                                            <div className="front">
                                                <h1 className="display-6 text-uppercase fw-bold text-secondary" style={{ marginLeft: '20px', marginBottom: '30px' }}>Galaxy Bar</h1>
                                                <div className="col mx-4">
                                                    <p className="mb-4" style={{ lineHeight: '1.7' }}>
                                                        An extension of the Galaxy restaurant,
                                                        the elegant bar showcases array of wines and beverages with
                                                        favorite bites and snacks to savor as you enjoy your drink.

                                                        Unwind after an exciting day in the bustling city of Nairobi. <br /><br />
                                                        Whether your visiting for business or leisure, the Galaxy bar
                                                        and bar deck is the ideal place to let the day run out with a large
                                                        selection of international wines, cocktails, beers, spirits and soft drinks.
                                                    </p>
                                                    <div className="d-grid d-sm-flex justify-content-sm-center">
                                                        <button type="button" className="btn btn-warning px-3 gap-3" style={{ padding: '10px 10px', color: 'white' }}>
                                                            <i className='fa fa-download' style={{ color: 'black', marginRight: '8px' }}></i>
                                                            VIEW BEVERAGES LIST
                                                        </button>
                                                    </div>
                                                </div>
                                            </div>
                                            <div className="dinning-back d-flex flex-column justify-content-center align-items-center">
                                                <i style={{ fontFamily: "serif" }}>
                                                    <p style={{ textAlign: 'center', fontSize: '35px', marginTop: '220px', textTransform: 'uppercase' }}>
                                                        "
                                                        First you'll Love <br />
                                                        Then you'll Live
                                                        "
                                                    </p>
                                                    <button type='submit' className='btn btn-warning bt-lg my-3 text-light' onClick={handleDownload}>
                                                        <i className='fa fa-download' style={{ color: 'black', marginRight: '8px' }}></i>
                                                        VIEW BEVERAGES LIST
                                                    </button>
                                                </i>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div className="col-10 col-sm-8 col-lg-6">
                        <div className='background-wrapper' style={{ marginLeft: '-24px', marginTop: '-50px' }}>
                            <div className='background-image3'></div>
                        </div>
                    </div>
                </div>
            </div>
            <div className="container-fluid" >
                <div className="row flex-lg-row-reverse align-items-center">
                    <div className="col-10 col-sm-8 col-lg-6">
                        <div className='background-wrapper' style={{ marginLeft: '-24px', marginTop: '-47px' }}>
                            <div className='background-image4'></div>
                        </div>
                    </div>
                    <div className="col-lg-6">
                        <div className='column-background-wrapper'>
                            <div className='column-background'>
                                <div className='column-content'>
                                    <div className={`flip-container ${isFlipped ? 'hover' : ''}`} onMouseEnter={handleFlip} onMouseLeave={handleFlip}>
                                        <div className="flipper">
                                            <div className="front" style={{ lineHeight: '2rem' }}>
                                                <img className="d-block mx-auto mb-4" src={DinnBlack} alt="" style={{ width: "120px", height: "100px" }} />
                                                <div className="col mx-4">
                                                    <p className="mb-4">
                                                        Eka Hotel offers dining at its best with the freshest flavors of locally sourced produce. It offers a
                                                        selected buffet breakfast, all-day a-la-carte and snack dining, flowing coffee/tea dispenser, and 24-hour
                                                        room service.
                                                        <br />
                                                        <br />
                                                        Spread out over the ground floor, the Galaxy (150 covers) showcases the finest cuisine, complete with live
                                                        show kitchen and an outdoor terrace overlooking the pool.
                                                    </p>
                                                </div>
                                            </div>
                                            <div className="dinning-back d-flex justify-content-center align-items-center">
                                                <i style={{ fontFamily: "serif" }}>
                                                    <p style={{ textAlign: 'center', fontSize: '35px', marginTop: '220px', textTransform: 'uppercase' }}>
                                                        "
                                                        Make Every Stay a <br />
                                                        Story Worth Telling
                                                        "
                                                    </p>
                                                </i>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div className='upperfoot' style={{ padding: '90px 0px 0px 0px', marginTop: '-118px' }}>
                <div className='background-wrapper'>
                    <div className='background-image5'>
                        <div className='container'>
                            <div className='upper-footer-head text-center align-items-center text-light fs-4 fw-bold d-block'>
                                <h3><b>Dinning Offers & Promotions</b></h3>
                                <span className="gdlr-core-title-item-title-divider gdlr-core-skin-divider"></span>
                            </div>
                            <div className="gdlr-core-pbf-element mb-2">
                                <div className="gdlr-core-divider-item gdlr-core-divider-item-small-center gdlr-core-item-pdlr">
                                    <div className="gdlr-core-divider-container" style={{ maxWidth: "80px" }}>
                                        <div className="gdlr-core-divider-line gdlr-core-skin-divider" style={{ borderColor: "#b78e00 " }}>
                                            <div className="gdlr-core-divider-line-bold  gdlr-core-skin-divider mt-3" style={{ borderColor: "#b78e00" }}></div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div className="container-fluid">
                                <div className="row flex-lg-row-reverse align-items-center g-5 py-4">
                                    <div className="col-10 col-sm-8 col-lg-6 promo-content">
                                        <div className='image-container scaleup'>
                                            <img src="https://i.pinimg.com/1200x/ec/67/5a/ec675a9c5374db674381eac23bc5de23.jpg" className="image_1 img-fluid" alt="left_advertisment" style={{ width: "320px", height: "300px", loading: "lazy" }} />
                                            <div className='overlay'>
                                                <p className='text-center text-light d-block fs-6 fw-small'>
                                                    End Of Year Offer
                                                    <span style={{ display: 'block' }}>
                                                        <i className="fa fa-plus-square-o"></i>
                                                    </span>
                                                </p>
                                            </div>
                                        </div>
                                        <h4 className='fs-6 fw-bold text-light my-2'>End Of Year Offer</h4>
                                    </div>
                                    <div className="col-lg-6 promo-content">
                                        <div className='image-container scaleup'>
                                            <img src="https://image.adsoftheworld.com/8r86iw3ks31v4g8bxi371wnsm9bz" className="image_1 img-fluid" alt="right_promotion" style={{ width: "290px", height: "300px", loading: "lazy" }} />
                                            <div className="overlay">
                                                <p className='text-center text-light d-block fs-6 fw-small'>
                                                    Limited Time Offer
                                                    <span style={{ display: 'block' }}>
                                                        <i className='fa fa-plus-square-o'></i>
                                                    </span>
                                                </p>
                                            </div>
                                        </div>
                                        <h4 className='fs-6 fw-bold text-light mb-1'>NAKP Exotic Beer</h4>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div className="px-4 py-2 my-1 text-center" style={{ background: '#eff' }}>
                <img className="d-block mx-auto mb-4" src={DinnBlack} alt="" style={{ width: "80px", height: "80px" }} />
                <h1 className="display-6 fs-2 fw-bold text-secondary">Call (+91)-8958321289 and reserve a table</h1>
                <div className="col-lg-6 mx-auto mt-4">
                    <p className="fs-6 lead fw-large mb-4">
                        Want to Refuge from your Home Life and have a Experience of Divine ?? ,<br />
                        We are always the option to consider !
                    </p>
                    <div className="d-grid gap-2 d-sm-flex justify-content-sm-center mt-2">
                        <Link to="/contact" className="btn btn-outline-dark contact-btn btn-lg px-4">
                            Contact Us
                        </Link>
                    </div>
                </div>
            </div>
            <Footer />
        </>
    )
}

export default Dinning;