import Footer from '../Footer/Footer';
import './css/Home.css';
import { Link } from 'react-router-dom';
import foodI from './Image/img5.webp';
import resto from './Image/restaurant.webp';
import Nav from '../Nav';


function Home() {

  return (
    <>
      <Nav />
      <div className='main'>
        <div className='background-Image'>

        </div>
        <div className='contain' style={{ backgroundColor: "lightgray" }}>
          <div className="container px-4 py-5">

            <div className="row row-cols-1 row-cols-md-2 align-items-md-center g-5 py-5">
              <div className="col d-flex flex-column align-items-start gap-2">
                <h2 className="fw-bold text-body-emphasis">NAKP Palace, Rishikesh</h2>
                <h5 className="text-body-secondary">Located 5 minute  from the nagar palika Rishikesh <br />
                  near by Johar Complex  </h5>
                <div className="gdlr-core-pbf-element">
                  <div className="gdlr-core-divider-item gdlr-core-divider-item-small-center gdlr-core-item-pdlr">
                    <div className="gdlr-core-divider-container" style={{ maxWidth: "80px" }}>
                      <div className="gdlr-core-divider-line gdlr-core-skin-divider" style={{ borderColor: "#b78e00 " }}>
                        <div className="gdlr-core-divider-line-bold  gdlr-core-skin-divider mt-3" style={{ borderColor: "#b78e00" }}></div>
                      </div>
                    </div>
                  </div>
                </div>
                <div className='confort'>
                  <h4>Comfort & Conveniences.....The only one! </h4>
                </div>

              </div>

              <div className="col">

                <div className="col d-flex flex-column gap-2">
                  <h5 className="text-body-primary" >NAKP PALACE is a contemporary 4-star hotel in Rishikesh, conveniently Located 5 minute  from the nagar palika Rishikesh, 5 minutes from JKIA through the express highway with close proximity to the Nairobi national park, major government and corporate organizations.

                    Eka Hotel Nairobi features 167 well-appointed rooms, five meeting & conference rooms, restaurant & bar, gym, swimming pool, gift shop, wellness center among other top facilities offering the best choice venue for your business and leisure stay.
                  </h5>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className='selector-bg'>
          <div className='container'>
            <div className='one row'>
              <div className='one col' style={{ color: "white" }}>
                <h4>
                  Book Direct Save 10%
                </h4>

                <div className='heading2' style={{ color: "white" }}>
                  <h5>
                    Book your accommodation directly <br /> on our website and save 10%.
                  </h5>
                </div>
                <div className='button' >
                  <button><Link className='btn link' to=''><b>Book Direct</b></Link></button>
                </div>
              </div>

              <div className=' two col'>
                <div className='heading3 container'>
                  <h2>
                    HOTEL ROOM
                  </h2>
                  <div className="gdlr-core-pbf-element">
                    <div className="gdlr-core-divider-item gdlr-core-divider-item-small-center gdlr-core-item-pdlr">
                      <div className="gdlr-core-divider-container" style={{ maxWidth: "80px" }}>
                        <div className="gdlr-core-divider-line gdlr-core-skin-divider" style={{ borderColor: "#b78e00 " }}>
                          <div className="gdlr-core-divider-line-bold  gdlr-core-skin-divider mt-3" style={{ borderColor: "#b78e00" }}></div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className='heading4'>
                    <h6 className='heads'>
                      Eka Hotel rooms are designed
                      <br />to provide
                      the highest levels of Comfort,
                      Convenience and Eﬃciency. <br /> The hotel
                      has 167 air-conditioned rooms,
                      of these 158  <br />are Superior rooms,
                      <br /> 2 rooms for guests with special
                      needs, 3 triple rooms,
                      1 Junior Suite and <br /> 3 Executive Suites.
                      Guests staying  <br />in the Hotel have
                      exclusive access  <br />to the gym and swimming pool.
                    </h6>
                    <div className='btntxt'>
                      <button ><Link className='btn' to='/rooms'>Get More Details</Link></button>
                    </div>
                  </div>
                </div>
              </div>

            </div>
          </div>
        </div>
        <div className='images row'>
          <div className='imgs col'>
            <img alt='' src={foodI} style={{ width: "125%" }} />
          </div>
          <div className='imgs2 col'>
            <div className='heads1 container'>
              <div className='headings8'>
                <h5>Enjoy Delactable</h5>
              </div>
              <div className='headings9'>
                <h4>
                  Dinning Experience At NAKP PALACE
                </h4>


              </div>
              <div className="gdlr-core-pbf-element">
                <div className="gdlr-core-divider-item gdlr-core-divider-item-small-center gdlr-core-item-pdlr">
                  <div className="gdlr-core-divider-container" style={{ maxWidth: "80px" }}>
                    <div className="gdlr-core-divider-line gdlr-core-skin-divider" style={{ borderColor: "#b78e00 " }}>
                      <div className="gdlr-core-divider-line-bold  gdlr-core-skin-divider mt-3" style={{ borderColor: "#b78e00" }}></div>
                    </div>
                  </div>
                </div>
              </div>
              <div className='imges'>
                <img alt='' src={resto} />
              </div>
            </div>
            <div className='headings9'>
              <h5>
                Eka Hotel has stirred up the local <br />culinary scene with two restaurants, two bars and <br />a 24-hr coffee shop that cater to the needs of our diverse clientele.<br /> Each dining experience provides our guests with a taste of a<br /> broad selection of international and local cuisine.
              </h5>
            </div>
            <div className='btntxt1'>
              <button ><Link className='btn' to='/dinning'>Dinning Option</Link></button>
            </div>
          </div>
        </div>
        <div className='metting'>
          <div className='metting  container'>
            <div className='headingss '>
              <h2 className='headds'>
                Metting & Events
              </h2>
              <div className="gdlr-core-pbf-element">
                <div className="gdlr-core-divider-item gdlr-core-divider-item-small-center gdlr-core-item-pdlr">
                  <div className="gdlr-core-divider-container" style={{ maxWidth: "80px" }}>
                    <div className="gdlr-core-divider-line gdlr-core-skin-divider" style={{ borderColor: "#b78e00 " }}>
                      <div className="gdlr-core-divider-line-bold  gdlr-core-skin-divider mt-3" style={{ borderColor: "#b78e00" }}></div>
                    </div>
                  </div>
                </div>
              </div>
              <div className='home-para'>
                <h6>
                  Located on the ground ﬂoor and the ﬁrst ﬂoor, the air-conditioned multi-functional 3 meeting rooms and 2 board rooms caters for up to 200 people theater style and can be adapted to suit speciﬁc needs of guests.

                  <br /><br />Each meeting room features natural day-light, state-of-the-art audiovisual equipment and a business center for the conference users.
                </h6>
                <div className='btntxt2'>
                  <button ><Link className='btn' to=''>Read More Books</Link></button>
                </div>
              </div>
            </div>

          </div>
        </div>
      </div>
      <div className='offers'>
        <div className='packages container'>
          <div className='packages-offer'>
            <h2 className='text-center mt-5 mb-2'>
              Packages & Special Offers
            </h2>
          </div>
          <div className='buttonss text-center mb-5'>
            <Link className='view text-center' to="">
              View All Offers
              <i className="fa fa-long-arrow-right" aria-hidden="true" style={{ marginLeft: '10px' }}></i>
            </Link>
          </div>
        </div>
        <div className="row row-cols-1 row-cols-md-3 mb-3 text-center">
          <div className="col">
            <div className="col-content card mx-auto" style={{ width: "18rem", boxShadow: '10px 10px 10px lightgrey' }}>
              <div className='image-container'>
                <img src="https://ekahotel.com/wp-content/uploads/2016/11/end-of-year-parties-jpg.webp" className="card-img-top image_1" alt="..." />
                <div className="overlay">
                  <i className="fa fa-plus-square-o"></i>
                </div>
              </div>
              <div className="card-body">
                <p className="card-text fs-5 fw-bold text-uppercase">End Of The Year Package</p>
              </div>
            </div>
          </div>
          <div className="col">
            <div className="col-content card" style={{ width: "18rem", boxShadow: '10px 10px 10px lightgrey' }}>
              <div className='image-container'>
                <img src="https://ekahotel.com/wp-content/uploads/2016/11/city-excursions.jpg" className="card-img-top image_1" alt="..." />
                <div className="overlay">
                  <i className="fa fa-plus-square-o"></i>
                </div>
              </div>
              <div className="card-body">
                <p className="card-text fs-5 fw-bold text-capitalize" >ENJOY EXCURSIONS BY NAKP HOTEL PALACE</p>
              </div>
            </div>
          </div>
          <div className="col">
            <div className="col-content card" style={{ width: "18rem", boxShadow: '10px 10px 10px lightgrey' }}>
              <div className='image-container'>
                <img src="https://ekahotel.com/wp-content/uploads/2016/11/weekend-staycation.jpg" className="card-img-top image_1" alt="..." />
                <div className="overlay">
                  <i className="fa fa-plus-square-o"></i>
                </div>
              </div>
              <div className="card-body">
                <p className="card-text text-uppercase fs-5 fw-bold">City Stayaction</p>
              </div>
            </div>
          </div>
          <div className="col mt-4">
            <div className=" mx-auto col-content card" style={{ width: "18rem", boxShadow: '10px 10px 10px lightgrey' }}>
              <div className='image-container'>
                <img src="https://ekahotel.com/wp-content/uploads/2016/11/eka-otl.jpg" className="card-img-top image_1" alt="..." />
                <div className="overlay">
                  <i className="fa fa-plus-square-o"></i>
                </div>
              </div>
              <div className="card-body">
                <p className="card-text text-uppercase fs-5 fw-bold">NAKP HOTEL PALACE – OLTUKAI LODGE EXCURSION</p>
              </div>
            </div>
          </div>
          <div className=" mt-4 col">
            <div className="col-content card" style={{ width: "18rem", boxShadow: '10px 10px 10px lightgrey' }}>
              <div className='image-container'>
                <img src="https://ekahotel.com/wp-content/uploads/2016/11/Eka-Draft-Beer.jpg" className="card-img-top image_1" alt="..." />
                <div className="overlay">
                  <i className="fa fa-plus-square-o"></i>
                </div>
              </div>
              <div className="card-body">
                <p className="card-text text-uppercase fs-5 fw-bold">NAKP EXOTIC BARS & DRINKS </p>
              </div>
            </div>
          </div>
          <div className=" mt-4 col">
            <div className="col-content card" style={{ width: "18rem", boxShadow: '10px 10px 10px lightgrey' }}>
              <div className='image-container'>
                <img src="https://ekahotel.com/wp-content/uploads/2016/11/eka-spa.jpg" className="card-img-top image_1" alt="..." />
                <div className="overlay">
                  <i className="fa fa-plus-square-o"></i>
                </div>
              </div>
              <div className="card-body">
                <p className="card-text text-uppercase fs-5 fw-bold">SPA WELLNESS CENTER</p>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div className="container-fluid col-xxl-8 px-4 py-5" style={{background:'lightgrey'}}>
        <div className="row flex-lg-row-reverse align-items-center g-5 py-5">
          <div className="col-10 col-sm-8 col-lg-6">
            <img src="https://media.istockphoto.com/id/1138930627/photo/fog-background.webp?b=1&s=170667a&w=0&k=20&c=ti9KozVINjnkPQvx6vV7AHvJE-RqQDb7Pf5QnqE42jc=" className="d-block mx-lg-auto img-fluid" alt="Bootstrap Themes" width="700" height="500" loading="lazy" />
            <p className='fs-6 text-light text-uppercase fw-large text-center' style={{ marginTop: '-200px', fontStyle: 'italic' }}>
              Figuring out where to spend your time ?<br />
              we are here for the good times
            </p>
          </div>
          <div className=" vertical list col-lg-6">
            <h1 className="display-6 fw-bold text-warning lh-1 mb-3" style={{marginLeft: '90px'}}>NAKP Palace Facilities</h1>
            <h4 className='fs-5 list-items text-secondary fw-bold' style={{marginLeft: '90px'}}>
              Rooms
              <div className="vertical-line"></div>
              Dinning
              <div className="vertical-line"></div>
              Meeting & Events
              <div className="vertical-line"></div>
              Leisure
            </h4>
            <div className="d-flex flex-column flex-md-row p-4  py-md-5 align-items-center justify-content-center">
              <div>
                <ul style={{ listStyle: 'none' }}>
                  <li>
                    <Link to="#" className="list-group-item list-group-item-action d-flex gap-3 py-3" aria-current="true">
                      <i className='fa fa-play rounded-circle flex-shrink-0' style={{ fontSize: '20px', color: 'orange' }}></i>
                      <div className="d-flex gap-2 w-100 justify-content-between">
                        <div>
                          <h6 className="mb-0">well-appointed guest rooms</h6>
                        </div>
                      </div>
                      <div className="d-flex gap-2 w-100 justify-content-between" style={{ marginLeft: '30px' }}>
                        <div>
                          <h6 className="mb-0">Restaurant with terrace</h6>
                        </div>
                      </div>
                    </Link>
                  </li>
                  <li>
                    <Link to="#" className="list-group-item list-group-item-action d-flex gap-3 py-3" aria-current="true">
                      <i className='fa fa-play rounded-circle flex-shrink-0' style={{ fontSize: '20px', color: 'orange' }}></i>
                      <div className="d-flex gap-2 w-100 justify-content-between">
                        <div>
                          <h6 className="mb-0">24hr Coffee /Lounge</h6>
                        </div>
                      </div>
                      <div className="d-flex gap-2 w-100 justify-content-between" style={{ marginLeft: '30px' }}>
                        <div>
                          <h6 className="mb-0">Bar & Deck</h6>
                        </div>
                      </div>
                    </Link>
                  </li>
                  <li>
                    <Link to="#" className="list-group-item list-group-item-action d-flex gap-3 py-3" aria-current="true">
                      <i className='fa fa-play rounded-circle flex-shrink-0' style={{ fontSize: '20px', color: 'orange' }}></i>
                      <div className="d-flex gap-2 w-100 justify-content-between">
                        <div>
                          <h6 className="mb-0">Swimming Pool</h6>
                        </div>
                      </div>
                    </Link>
                  </li>
                  <li>
                    <Link to="#" className="list-group-item list-group-item-action d-flex gap-3 py-3" aria-current="true">
                      <i className='fa fa-play rounded-circle flex-shrink-0' style={{ fontSize: '20px', color: 'orange' }}></i>
                      <div className="d-flex gap-2 w-100 justify-content-between">
                        <div>
                          <h6 className="mb-0">Free and Fast Wifi</h6>
                        </div>
                      </div>
                    </Link>
                  </li>
                  <li>
                    <Link to="#" className="list-group-item list-group-item-action d-flex gap-3 py-3" aria-current="true">
                      <i className='fa fa-play rounded-circle flex-shrink-0' style={{ fontSize: '20px', color: 'orange' }}></i>
                      <div className="d-flex gap-2 w-100 justify-content-between">
                        <div>
                          <h6 className="mb-0">Spa Wellness Centre</h6>
                        </div>
                      </div>
                    </Link>
                  </li>
                  <li>
                    <Link to="#" className="list-group-item list-group-item-action d-flex gap-3 py-3" aria-current="true">
                      <i className='fa fa-play rounded-circle flex-shrink-0' style={{ fontSize: '20px', color: 'orange' }}></i>
                      <div className="d-flex gap-2 w-100 justify-content-between">
                        <div>
                          <h6 className="mb-0">Gaming Room</h6>
                        </div>
                      </div>
                    </Link>
                  </li>
                  <li>
                    <Link to="#" className="list-group-item list-group-item-action d-flex gap-3 py-3" aria-current="true">
                      <i className='fa fa-play rounded-circle flex-shrink-0' style={{ fontSize: '20px', color: 'orange' }}></i>
                      <div className="d-flex gap-2 w-100 justify-content-between">
                        <div>
                          <h6 className="mb-0">Adventure Sports & Tourism</h6>
                        </div>
                      </div>
                    </Link>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div className='brandaffiliation' style={{boxShadow: '20p 20px 20px lightgrey'}}>
        <div className='fonticons-flex'>
          <div className='left-font-text'>
            <h3 className='lefttext text-capitalizze fs-5'>
              Check us out here too --
            </h3>
          </div>
          <div className='right-font-icons'>
            <div className='allicons'>
              <div className='instagram'>
                <i className='fa fa-instagram'></i>
              </div>
              <div className='facebook'>
                <i className='fa fa-facebook'></i>
              </div>
              <div className='twitter'>
                <i className='fa fa-twitter'></i>
              </div>
            </div>
          </div>
        </div>
      </div>
      <Footer />
    </>
  )
}

export default Home