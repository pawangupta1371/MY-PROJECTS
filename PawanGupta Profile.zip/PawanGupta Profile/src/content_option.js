const logotext = "PAWAN";
const meta = {
    title: "Pawan Gupta",
    description: "I’m Pawan gupta data scientist _ Full stack devloper,currently working in Dev b Infotech",
};

const introdata = {
    title: "I’m Pawan Gupta",
    animated: {
        first: "I love coding",
        second: "I code cool websites",
        third: "I am Full-stack developer",
    },
    description: "I believe I am well suited for this role due to my expertise in various top rated technologies including web frameworks like ReactJs, html css & Js , AsP. NET core ; databases like MongoDB and SQL Server; and backend languages like NodeJs.",
    your_img_url: "https://images.unsplash.com/photo-1514790193030-c89d266d5a9d",
};

const dataabout = {
    title: "abit about my self",
    aboutme: "I believe I am well suited for this role due to my expertise in various top rated technologies including web frameworks like ReactJs, html css & Js , AsP. NET core ; databases like MongoDB and SQL Server; and backend languages like NodeJs.",
};
const worktimeline = [{
        jobtitle: "Forntend Developer",
        where: "Dev B Infotech",
        date: "2022",
    },
    {
        jobtitle: "Backend Developer",
        where: "Dec B Infotech",
        date: "2023",
    },
    {
        jobtitle: "full-Stack Developer",
        where: "Dev B Infotech",
        date: "2024",
    },
];

const skills = [{
        name: "HTML & CSS ,JS",
        value: 90,
    },
    {
        name: "REACT",
        value: 85,
    },
    {
        name: "NODE",
        value: 80,
    },
    {
        name: ".NET CORE",
        value: 60,
    },
    {
        name: "MERN",
        value: 85,
    },
];

const services = [{
        title: "Website design",
        description: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed at nisl euismod urna bibendum sollicitudin.",
    },
    {
        title: "Mobile Apps",
        description: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed at nisl euismod urna bibendum sollicitudin.",
    },
    {
        title: "Wordpress Design",
        description: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed at nisl euismod urna bibendum sollicitudin.",
    },
];

const dataportfolio = [{
        img: "https://picsum.photos/400/?grayscale",
        description: "The wisdom of life consists in the elimination of non-essentials.",
        link: "#",
    },
    {
        img: "https://picsum.photos/400/800/?grayscale",
        description: "The wisdom of life consists in the elimination of non-essentials.",
        link: "#",
    },
    {
        img: "https://picsum.photos/400/?grayscale",
        description: "The wisdom of life consists in the elimination of non-essentials.",
        link: "#",
    },
    {
        img: "https://picsum.photos/400/600/?grayscale",
        description: "The wisdom of life consists in the elimination of non-essentials.",
        link: "#",
    },
    {
        img: "https://picsum.photos/400/300/?grayscale",
        description: "The wisdom of life consists in the elimination of non-essentials.",
        link: "#",
    },
    {
        img: "https://picsum.photos/400/700/?grayscale",
        description: "The wisdom of life consists in the elimination of non-essentials.",
        link: "#",
    },

    {
        img: "https://picsum.photos/400/600/?grayscale",
        description: "The wisdom of life consists in the elimination of non-essentials.",
        link: "#",
    },
    {
        img: "https://picsum.photos/400/300/?grayscale",
        description: "The wisdom of life consists in the elimination of non-essentials.",
        link: "#",
    },
    {
        img: "https://picsum.photos/400/?grayscale",
        description: "The wisdom of life consists in the elimination of non-essentials.",
        link: "#",
    },
    {
        img: "https://picsum.photos/400/550/?grayscale",
        description: "The wisdom of life consists in the elimination of non-essentials.",
        link: "#",
    },
    {
        img: "https://picsum.photos/400/?grayscale",
        description: "The wisdom of life consists in the elimination of non-essentials.",
        link: "#",
    },
    {
        img: "https://picsum.photos/400/700/?grayscale",
        description: "The wisdom of life consists in the elimination of non-essentials.",
        link: "#",
    },
];

const contactConfig = {
    YOUR_EMAIL: "pawangupta1371@gmail.com",
    YOUR_FONE: "8449588030",
    description: "I am Pawan Gupta from Uttarakhand in living Rishikesh. I have completed my eduction Bac and Mca from HNBUG university form Uttarakhand. I have 1 year Experiance in web Developer in Dev B infotech company. i am skilled variose technologyes like HTMS AND CSS , JS , REACT, NODE, SQL, MERN ect.  ",
    // creat an emailjs.com account 
    // check out this tutorial https://www.emailjs.com/docs/examples/reactjs/
    YOUR_SERVICE_ID: "service_id",
    YOUR_TEMPLATE_ID: "template_id",
    YOUR_USER_ID: "user_id",
};

const socialprofils = {
    github: "https://github.com/pawangupta1371/MY-PROJECTS",
    facebook: "https://facebook.com",
    linkedin: "https://linkedin.com",
    twitter: "https://twitter.com",
};
export {
    meta,
    dataabout,
    dataportfolio,
    worktimeline,
    skills,
    services,
    introdata,
    contactConfig,
    socialprofils,
    logotext,
};