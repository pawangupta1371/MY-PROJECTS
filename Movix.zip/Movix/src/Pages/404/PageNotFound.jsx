import React from 'react'

function PageNotFound() {
  return (
    <div>
      error
    </div>
  )
}

export default PageNotFound
